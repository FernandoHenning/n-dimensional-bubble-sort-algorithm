def bubble_sort(arr, pos = 3) -> list:
    n = len(arr) - 1 # Menos uno porque la matriz comienza desde 0, así que el último índice es 49.
    for i in range(n):
        # En cada ciclo de comparación la "burbuja" más grande irá poniéndonse en la primer posición de la matriz,
        # así, i representa a todos lo valores ya ordenados por lo que el siguiente ciclo se realiza n - i (valores ya ordenados) veces.
        for j in range(0, n-i):
            # Se intercambia si el valor actual es mayor que el siguiente
            if arr[j][pos] > arr[j+1][pos] :
                arr[j], arr[j+1] = arr[j+1], arr[j]    
    return arr

def read_data(file_name: str) -> list:
    data = []
    with open(file_name + ".txt") as data_file: 
        for line in data_file: # Se lee cada linea del archivo
            line = line.replace("\n","") # Al final de cada linea se encuentra el símbolo de salto de linea por lo que se elimina.
            newline = line.rstrip(",").split(",")  # Se crea una lista diviendo la linea por cada , (coma) encontrada
            data.append(newline) # La lista se agrega a la última posición de la matriz
    return data

if __name__ == '__main__':
    import pandas as pd # Libreía de python para imprimir la matriz alineada y con encabezados.
    data = read_data("datos")
    print("|---------------------.-------No ordenado----------------------------|")
    printable = pd.DataFrame(data, columns=["Apellido paterno","Apellido materno","Nombre","CURP"])
    print(printable.to_string(index=False))
    data = bubble_sort(data)
    printable = pd.DataFrame(data, columns=["Apellido paterno","Apellido materno","Nombre","CURP"])
    print("\n|------------------------------Ordenado------------------------------|")
    print(printable.to_string(index=False))
    
"""
    Algoritmo Bubble Sort para ordenar una matriz de datos leídos desde una archivo de texto.
    Los datos almacenados en el archivo de texto son:
        - Apellido paterno
        - Apellido Materno
        - Nombre o nombres
        - CURP
    Requisitos:
    - Tener la librería Pandas instalada. (puede funcionar sin ella, pero se tendría que modificar la forma de imprimir la matriz)

    Función Bubble Sort
        Parámetros:
            - arr: Matriz de datos a ordenar (este algorítmo está modificado para funcionar con matrices, no con listas)
            - pos: Posición de la lista a la cual se le realizará la comparación. Por defecto es 3 el cual corresponde a la CURP
        Salida:
            - Una matriz ordenaba con base a la CURP

    Matriz generada (lista de listas):
        APELLIDO PATERNO, APELLIDO MATERNO, NOMBRE, CURP
        [                |              |         |       ],
        [                |              |         |       ],
        [                |              |         |       ],
        
    Nota: recuerda almacenar los datos en el archivo de texto tal y como están, separados por comas (sin espacios).
        Ejemplo: Apellido1,Apellido2,Nombre,CUPR
    2
    * borra esto cuando gustes * 
"""